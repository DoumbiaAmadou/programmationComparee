1,$s/_//g
g/GAMES AND DEMOS/-2,-1d
g/GAMES AND DEMOS/+1d
g/Last change:/-1d
g/Last change:/+1,+2d
1,$s/^/      /
wq
